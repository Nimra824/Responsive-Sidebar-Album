 📂 Responsive Sidebar Album
A **Bootstrap 5-based responsive layout** featuring a collapsible sidebar, fixed top navbar, and card-based album section.  
The sidebar automatically adapts to screen size — visible on desktop and collapsible on mobile — making it ideal for modern responsive designs.

🚀 Features
- 📱 Fully Responsive – adapts to mobile, tablet, and desktop screens.  
- 📂 Collapsible Sidebar – toggle sidebar navigation with smooth transitions.  
- 🖼️ Album Layout– card-based content grid for showcasing items (images, text, etc.).  
- 🎨 Bootstrap 5 Styling– clean and modern UI using Bootstrap’s utilities.  
- 🔄 Dynamic Behavior– sidebar auto-hides on mobile when a link is clicked.  

🛠️ Technologies Used
--HTML5
--CSS3  
--Bootstrap5  
--JavaScript(Vanilla)  

📖 How to Run
1. Clone or download the repository:
   ```bash
   git clone https://github.com/YourUsername/Responsive-Sidebar-Album.git
##Demo Screenshot
screenshot.png
##Use Cases
--Dashboards
--Portfolios
--Album / Gallery Layouts
--Content-driven Websites

Author

Developed by [Nimra Iqbal]
📧 Contact: nimraiqbal7071@gmail.com